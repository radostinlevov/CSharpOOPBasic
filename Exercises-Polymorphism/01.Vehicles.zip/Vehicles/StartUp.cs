﻿using System;
using Vehicles.Classes;

namespace Vehicles
{
    public class StartUp
    {
        public static void Main()
        {
            string[] firstLine = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string firstTypeOfVehicle = firstLine[0];
            double firstFuelQuantity = double.Parse(firstLine[1]);
            double firstFuelConsumptionLittersPerKm = double.Parse(firstLine[2]);

            Vehicle car = new Car(firstTypeOfVehicle, firstFuelQuantity, firstFuelConsumptionLittersPerKm);

            string[] secondLine = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            string secondTypeOfVehicle = secondLine[0];
            double secondFuelQuantity = double.Parse(secondLine[1]);
            double secondFuelConsumptionLittersPerKm = double.Parse(secondLine[2]);

            Vehicle truck = new Truck(secondTypeOfVehicle, secondFuelQuantity, secondFuelConsumptionLittersPerKm);

            int numberOfCommands = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfCommands; i++)
            {
                string[] commandTokens = Console.ReadLine().Split(new[] {' '}, StringSplitOptions.RemoveEmptyEntries);
                string command = commandTokens[0];
                string typeOfVehicle = commandTokens[1];

                switch (command)
                {
                    case "Drive":
                        double distanceToDrive = double.Parse(commandTokens[2]);
                        switch (typeOfVehicle)
                        {
                            case "Car":
                                Console.WriteLine(car.Drive(distanceToDrive));
                                
                                break;
                            case "Truck":
                                Console.WriteLine(truck.Drive(distanceToDrive));
                                break;
                        }
                        break;
                    case "Refuel":
                        double refuelInLitters = double.Parse(commandTokens[2]);
                        switch (typeOfVehicle)
                        {
                            case "Car":
                                car.Refuel(refuelInLitters);
                                break;
                            case "Truck":
                                truck.Refuel(refuelInLitters);
                                break;
                        }
                        break;
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
        }
    }
}
