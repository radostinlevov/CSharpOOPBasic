﻿namespace Vehicles.Classes
{
    public class Truck : Vehicle
    {
        private const double percentRefuel = 95d / 100d; 
        public Truck(string typeOfVehicle, double fuelQuantity, double fuelConsumptionLittersPerKm)
            : base(typeOfVehicle, fuelQuantity, fuelConsumptionLittersPerKm)
        {
        }

        public override double FuelConsumptionLittersPerKm
        {
            get
            {
                return base.FuelConsumptionLittersPerKm;
            }
            protected set
            {
                base.FuelConsumptionLittersPerKm = value + 1.6;
            }
        }

        public override void Refuel(double refuelInLitters)
        {
            base.Refuel(percentRefuel * refuelInLitters);
        }
    }
}
