﻿namespace Vehicles.Classes
{
    public abstract class Vehicle
    {
        private string typeOfVehicle;
        private double fuelQuantity;
        private double fuelConsumptionLittersPerKm;

        protected Vehicle(string typeOfVehicle, double fuelQuantity, double fuelConsumptionLittersPerKm)
        {
            this.TypeOfVehicle = typeOfVehicle;
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumptionLittersPerKm = fuelConsumptionLittersPerKm;
        }

        public string TypeOfVehicle
        {
            get
            {
                return this.typeOfVehicle;
            }
            protected set
            {
                this.typeOfVehicle = value;
            }
        }

        public virtual double FuelQuantity
        {
            get
            {
                return this.fuelQuantity;
            }
            protected set
            {
                this.fuelQuantity = value;
            }
        }

        public virtual double FuelConsumptionLittersPerKm
        {
            get
            {
                return this.fuelConsumptionLittersPerKm;
            }
            protected set
            {
                this.fuelConsumptionLittersPerKm = value;
            }
        }

        public virtual string Drive(double distanceToDrive)
        {
            double availableKm = this.FuelQuantity / this.FuelConsumptionLittersPerKm;
            double fuelConsumptionInLitters = distanceToDrive * this.FuelConsumptionLittersPerKm;

            if (availableKm >= distanceToDrive)
            {
                this.FuelQuantity -= fuelConsumptionInLitters;
                return $"{this.TypeOfVehicle} travelled {distanceToDrive} km";
            }

            return $"{this.TypeOfVehicle} needs refueling";

        }

        public virtual void Refuel(double refuelInLitters)
        {
            this.FuelQuantity += refuelInLitters;
        }
    }
}
